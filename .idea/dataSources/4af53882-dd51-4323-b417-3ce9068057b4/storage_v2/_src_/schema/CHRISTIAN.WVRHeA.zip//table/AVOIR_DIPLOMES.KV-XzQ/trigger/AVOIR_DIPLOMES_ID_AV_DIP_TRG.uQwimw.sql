create trigger AVOIR_DIPLOMES_ID_AV_DIP_TRG
    before insert
    on AVOIR_DIPLOMES
    for each row
begin
            if :new.ID_AV_DIP is null then
                select avoir_diplomes_id_av_dip_seq.nextval into :new.ID_AV_DIP from dual;
            end if;
            end;
/

