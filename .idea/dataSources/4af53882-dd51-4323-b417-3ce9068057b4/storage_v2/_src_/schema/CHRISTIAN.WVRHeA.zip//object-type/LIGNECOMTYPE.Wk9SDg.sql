create TYPE LigneComType AS OBJECT
(
qteCom NUMBER,
refProd NUMBER
)
/

