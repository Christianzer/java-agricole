create TYPE ProduitType AS OBJECT
(numProd NUMBER,  
 designation VARCHAR2(255),
 prixU NUMBER,
 qteStock NUMBER
)
/

