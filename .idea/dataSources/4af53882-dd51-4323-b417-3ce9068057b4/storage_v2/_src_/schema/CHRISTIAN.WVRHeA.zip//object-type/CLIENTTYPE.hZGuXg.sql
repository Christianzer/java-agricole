create TYPE ClientType AS OBJECT
(numCl NUMBER,  
 nom VARCHAR2(255)
)
/

