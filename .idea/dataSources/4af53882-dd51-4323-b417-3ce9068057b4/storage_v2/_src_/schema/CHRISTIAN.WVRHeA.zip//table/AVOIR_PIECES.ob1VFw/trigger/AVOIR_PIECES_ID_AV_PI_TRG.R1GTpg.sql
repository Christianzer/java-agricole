create trigger AVOIR_PIECES_ID_AV_PI_TRG
    before insert
    on AVOIR_PIECES
    for each row
begin
            if :new.ID_AV_PI is null then
                select avoir_pieces_id_av_pi_seq.nextval into :new.ID_AV_PI from dual;
            end if;
            end;
/

