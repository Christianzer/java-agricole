create trigger TYPE_PIECES_ID_PIECE_TRG
    before insert
    on TYPE_PIECES
    for each row
begin
            if :new.ID_PIECE is null then
                select type_pieces_id_piece_seq.nextval into :new.ID_PIECE from dual;
            end if;
            end;
/

