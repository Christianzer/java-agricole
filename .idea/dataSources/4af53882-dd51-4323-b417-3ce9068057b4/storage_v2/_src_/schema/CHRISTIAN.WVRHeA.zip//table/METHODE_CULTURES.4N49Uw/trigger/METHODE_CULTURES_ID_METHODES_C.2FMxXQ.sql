create trigger METHODE_CULTURES_ID_METHODES_C
    before insert
    on METHODE_CULTURES
    for each row
begin
            if :new.ID_METHODES_CULTURES is null then
                select methode_cultures_id_methodes_c.nextval into :new.ID_METHODES_CULTURES from dual;
            end if;
            end;
/

