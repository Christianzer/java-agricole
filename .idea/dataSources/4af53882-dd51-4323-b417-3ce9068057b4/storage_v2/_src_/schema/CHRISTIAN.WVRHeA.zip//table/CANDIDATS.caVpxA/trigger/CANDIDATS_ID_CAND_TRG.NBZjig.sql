create trigger CANDIDATS_ID_CAND_TRG
    before insert
    on CANDIDATS
    for each row
begin
            if :new.ID_CAND is null then
                select candidats_id_cand_seq.nextval into :new.ID_CAND from dual;
            end if;
            end;
/

