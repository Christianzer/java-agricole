create trigger TYPE_CULTURES_ID_TYPE_CULTURES
    before insert
    on TYPE_CULTURES
    for each row
begin
            if :new.ID_TYPE_CULTURES is null then
                select type_cultures_id_type_cultures.nextval into :new.ID_TYPE_CULTURES from dual;
            end if;
            end;
/

