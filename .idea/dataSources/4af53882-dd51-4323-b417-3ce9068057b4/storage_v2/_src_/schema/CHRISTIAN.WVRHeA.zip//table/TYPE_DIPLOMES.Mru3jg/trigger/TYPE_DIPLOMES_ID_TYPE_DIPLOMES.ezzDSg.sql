create trigger TYPE_DIPLOMES_ID_TYPE_DIPLOMES
    before insert
    on TYPE_DIPLOMES
    for each row
begin
            if :new.ID_TYPE_DIPLOMES is null then
                select type_diplomes_id_type_diplomes.nextval into :new.ID_TYPE_DIPLOMES from dual;
            end if;
            end;
/

