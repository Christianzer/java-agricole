create trigger DOSSIER_INSCRIPTIONS_DOSSIER_T
    before insert
    on DOSSIER_INSCRIPTIONS
    for each row
begin
            if :new.DOSSIER is null then
                select dossier_inscriptions_dossier_s.nextval into :new.DOSSIER from dual;
            end if;
            end;
/

