create trigger PLANTATION_CANDIDATS_ID_PLANT_
    before insert
    on PLANTATION_CANDIDATS
    for each row
begin
            if :new.ID_PLANT is null then
                select plantation_candidats_id_plant_.nextval into :new.ID_PLANT from dual;
            end if;
            end;
/

