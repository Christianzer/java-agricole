create trigger MIGRATIONS_ID_TRG
    before insert
    on MIGRATIONS
    for each row
begin
            if :new.ID is null then
                select migrations_id_seq.nextval into :new.ID from dual;
            end if;
            end;
/

