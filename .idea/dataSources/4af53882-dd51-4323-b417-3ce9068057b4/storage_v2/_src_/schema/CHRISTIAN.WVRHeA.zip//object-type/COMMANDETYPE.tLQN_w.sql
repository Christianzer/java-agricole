create TYPE CommandeType AS OBJECT
(numCom NUMBER,
 espasse REF clientType,  
 ComLigne LignesComType,
 dateCom DATE
);
/

