create trigger AVOIR_CULTURES_ID_AV_CULT_TRG
    before insert
    on AVOIR_CULTURES
    for each row
begin
            if :new.ID_AV_CULT is null then
                select avoir_cultures_id_av_cult_seq.nextval into :new.ID_AV_CULT from dual;
            end if;
            end;
/

