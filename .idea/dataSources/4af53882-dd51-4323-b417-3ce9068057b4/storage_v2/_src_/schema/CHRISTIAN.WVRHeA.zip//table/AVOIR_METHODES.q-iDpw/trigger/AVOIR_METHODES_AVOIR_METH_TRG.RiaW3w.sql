create trigger AVOIR_METHODES_AVOIR_METH_TRG
    before insert
    on AVOIR_METHODES
    for each row
begin
            if :new.AVOIR_METH is null then
                select avoir_methodes_avoir_meth_seq.nextval into :new.AVOIR_METH from dual;
            end if;
            end;
/

