create trigger USERS_ID_USERS_TRG
    before insert
    on USERS
    for each row
begin
            if :new.ID_USERS is null then
                select users_id_users_seq.nextval into :new.ID_USERS from dual;
            end if;
            end;
/

