create trigger EMPLOYE_CANDIDATS_ID_EMPL_CAND
    before insert
    on EMPLOYE_CANDIDATS
    for each row
begin
            if :new.ID_EMPL_CAND is null then
                select employe_candidats_id_empl_cand.nextval into :new.ID_EMPL_CAND from dual;
            end if;
            end;
/

