create trigger ETATS_ID_TABLE_TRG
    before insert
    on ETATS
    for each row
begin
            if :new.ID_TABLE is null then
                select etats_id_table_seq.nextval into :new.ID_TABLE from dual;
            end if;
            end;
/

